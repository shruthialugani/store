package ibmmobileappbuilder.cloudant.sync.datastore;

public interface DatabaseSyncFinishedListener {
    void onSynchronized();
}
